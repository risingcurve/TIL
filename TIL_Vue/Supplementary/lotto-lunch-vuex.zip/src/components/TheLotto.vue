<template>
  <div>
    Lotto
    <!-- <button @click="getNumbers">번호 준비</button> -->
    <button @click="getLottoNums">로또 추첨</button>
    <p>{{ lotto }}</p>
  </div>
</template>

<script>
import _ from 'lodash'

export default {
  name: 'TheLotto',
  data () {
    return {
      numbers: null,
      // lottoNums: null,  // vuex 로 이동
    }
  },
  methods: {
    getNumbers () {
      this.numbers = _.range(1, 46)
    },

    getLottoNums () {
      const lottoNums = _.sampleSize(this.numbers, 6)  // vuex 에서 저장
      this.$store.dispatch('setLottoNums', lottoNums)
    }
  },
  computed: {
    lotto () {
      return this.$store.getters.lotto
    }
  },
  // Life Cycle Hook 사용
  // method 로 정의
  created () {
    // 처리하고 싶은 로직을 작성
    console.log('created!!!!!!!')
    this.getNumbers()
  }
}
</script>

<style>

</style>