<template>
  <div>
    Lunch
    <button @click="getMenu">메뉴 고르기</button>
    <p>{{ lunchMenu }}</p>
  </div>
</template>

<script>
export default {
  name: 'TheLunch', 
  data () {
    return {
      lunchMenus: ['짜장면', '짬뽕', '국밥', '피자', '치킨']
    }
  },
  methods: {
    getMenu () {
      // 뽑는 로직을 이번에는 actions 에서 진행
      this.$store.dispatch('getLunchMenu', this.lunchMenus)
    }
  },
  computed: {
    lunchMenu () {
      return this.$store.getters.lunch
    }
  }
}
</script>

<style>

</style>