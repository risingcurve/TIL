import Vue from 'vue'
import Vuex from 'vuex'
import _ from 'lodash'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    lottoNums: null,
    lunch: null,
  },
  getters: {
    // 첫 번째 인자로 state
    lotto (state) {
      return state.lottoNums
    },

    lunch (state) {
      return state.lunch
    }
  },
  mutations: {
    // 첫 번째 인자는 state
    SET_LOTTO_NUMS (state, data) {
      console.log('mutation!!!!!!!')
      state.lottoNums = data
    },

    SET_LUNCH_MENU (state, lunchMenu) {
      state.lunch = lunchMenu
    }
  },
  actions: {
    // 첫 번째 인자가 context 
    setLottoNums (context, data) {
      // console.log('actions!!!', data)
      context.commit('SET_LOTTO_NUMS', data)
    },

    getLunchMenu (context, lunchMenus) {
      const menu = _.sample(lunchMenus)
      context.commit('SET_LUNCH_MENU', menu)
    }
  },
  modules: {
  }
})
