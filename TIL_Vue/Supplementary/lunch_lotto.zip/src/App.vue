<template>
  <div id="app">
    <!-- 3. 사용하기 -->
    <TheLunch @pick-menu="getMenu"/>
    <TheLotto v-if="menu" :lunchMenu="menu" />
  </div>
</template>

<script>
// 1. 불러오기
import TheLunch from '@/components/TheLunch'
import TheLotto from '@/components/TheLotto'

export default {
  name: 'App',
  components: {
    // 2. 등록하기
    TheLunch,
    TheLotto,
  },
  data() {
    return {
      menu: null,
    }
  },
  methods: {
    getMenu: function (pickMenu) {
      this.menu = pickMenu
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
