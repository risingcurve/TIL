<template>
  <div>
    <h1>{{ lunchMenu }}먹고 로또 추첨</h1>
    <button @click="getLuckyNum">Get Lucky Numbers</button>
    <p>{{ numbers }}</p>
  </div>
</template>

<script>
import _ from 'lodash'

export default {
    name: 'TheLotto',
    data() {
        return {
            numbers: null,
        }
    },
    props: {
        lunchMenu: String,
    },
    methods: {
        getLuckyNum: function () {
            const numbers = _.range(1, 46)
            const luckyNum = _.sampleSize(numbers, 6)
            this.numbers = luckyNum
        }
    }
}
</script>

<style>

</style>