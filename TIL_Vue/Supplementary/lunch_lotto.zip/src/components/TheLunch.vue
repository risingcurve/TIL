<template>
  <div>
    <h1>점심 메뉴</h1>
    <button @click="getLunchMenu">Pick One</button>
    <p>{{ lunchMenu }}</p>
    <hr>
  </div>
</template>

<script> 
import _ from 'lodash'

export default {
    name: 'TheLunch',
    data() {
        return {
            lunchList: ['짜장면', '라면', '국박', '햄버거', '피자', '족발'],
            lunchMenu: null,
        }
    },
    methods: {
        getLunchMenu: function () {
            const pickMenu = _.sample(this.lunchList)
            this.lunchMenu = pickMenu   

            // 부모로 data 전달
            this.$emit('pick-menu', pickMenu)
        }
    }
}
</script>

<style>

</style>